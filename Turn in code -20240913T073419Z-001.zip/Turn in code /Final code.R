install.packages('tidyverse')
install.packages('dplyr')
install.packages('readr')
install.packages('ggplot2')
install.packages('stringr')
install.packages('googlesheets4')
install.packages('readxl')
install.packages('sf')
library(tidyverse)
library(dplyr)
library(readr)
library(ggplot2)
library(stringr)
library(googlesheets4)
library(readxl)
library(sf)

#Create code variable to used in chloropleth map
code <- read_xlsx('Copy of Country Code.xlsx')
colnames(code) <- c('Area','code','iso code')

#Create large data set named oil
oil <- read_csv('FAOSTAT_all_oil.csv')
oil <- right_join(code, oil, by='Area')
oil <- oil[c(1,3,10,12,14)]

#Rename some countries to more readable names
oil <- oil %>% mutate(Area = str_replace(Area, 'America', NA_character_)) %>% mutate(Area = replace_na(Area, 'U.S.A'))
oil <- oil %>% mutate(Area = str_replace(Area, 'slamic', NA_character_)) %>% mutate(Area = replace_na(Area, 'Iran'))
oil <- oil %>% mutate(Area = str_replace(Area, 'Britain', NA_character_)) %>% mutate(Area = replace_na(Area, 'U.K.'))
oil <- oil %>% mutate(Area = str_replace(Area, 'Bolivia', NA_character_)) %>% mutate(Area = replace_na(Area, 'Bolivia'))
oil <- oil %>% mutate(Area = str_replace(Area, 'rkiye', NA_character_)) %>% mutate(Area = replace_na(Area, 'Turkey'))
oil <- oil %>% mutate(Area = str_replace(Area, 'Russia', NA_character_)) %>% mutate(Area = replace_na(Area, 'Russia'))
oil <- oil %>% mutate(Area = str_replace(Area, 'Democratic Republic of the Congo', NA_character_)) %>% mutate(Area = replace_na(Area, 'D.R.C'))
oil <- oil %>% mutate(Area = str_replace(Area, 'Syrian', NA_character_)) %>% mutate(Area = replace_na(Area, 'Syria'))

#Create 6 tibbles based on specific type of oil
palmoil <- oil %>% filter(grepl('Palm oil', Item))
sunflower <- oil %>% filter(grepl('Sunflower-seed', Item))
cotton <- oil %>% filter(grepl('Cotton', Item))
olive <- oil %>% filter(grepl('Olive', Item))
soy <- oil %>% filter(grepl('Soy', Item))
canola <- oil %>% filter(grepl('Rapeseed', Item))

#Create a tibble with the total amount of each different plant oil produced each year
total <- tibble(Year = 1961:2019, Palm=NA, Sunflower=NA, Cotton=NA, Olive=NA, Soy=NA, Canola=NA) 
total[,'Palm'] <- (oil %>% filter(grepl('Palm oil', Item)) %>% na.omit() %>% group_by(Year) %>% summarise(sum(Value)))$`sum(Value)`
total[,'Sunflower'] <- (oil %>% filter(grepl('Sunflower', Item)) %>% na.omit() %>% group_by(Year) %>% summarise(sum(Value)))$`sum(Value)`
total[,'Cotton'] <- (oil %>% filter(grepl('Cotton', Item)) %>% na.omit() %>% group_by(Year) %>% summarise(sum(Value)))$`sum(Value)`
total[,'Olive'] <- (oil %>% filter(grepl('Olive', Item)) %>% na.omit() %>% group_by(Year) %>% summarise(sum(Value)))$`sum(Value)`
total[,'Soy'] <- (oil %>% filter(grepl('Soy', Item)) %>% na.omit() %>% group_by(Year) %>% summarise(sum(Value)))$`sum(Value)`
total[,'Canola'] <- (oil %>% filter(grepl('Rapeseed', Item)) %>% na.omit %>% group_by(Year) %>% summarise(sum(Value)))$`sum(Value)`                      

#Make a line graph with 6 different lines, one for each type of oil given a specific corresponding color
#Figure 1
ggplot(data = total) + 
  geom_line(aes(x = Year, y = Palm, color = 'Palm')) +
  geom_line(aes(x = Year, y = Sunflower, color = 'Sunflower')) +
  geom_line(aes(x = Year, y = Cotton, color = 'Cotton')) +
  geom_line(aes(x = Year, y = Olive, color = 'Olive')) +
  geom_line(aes(x = Year, y = Soy, color = 'Soy')) +
  geom_line(aes(x = Year, y = Canola, color = 'Canola')) +
  scale_color_manual(name = 'Oil Type', values = c('Palm' = 'red', 'Sunflower' = 'green', 'Cotton' = 'blue', 'Olive' = 'brown', 'Soy' = 'orange', 'Canola' = 'pink')) +
  labs(title = "Total World Oil Production", x = "Year", y = "tonnes") +
  theme(plot.title = element_text(hjust = .5))

#Row bind a new table together with the top 10 countries based on production values for each oil for each year
big <- oil %>% na.omit() %>% filter(grepl("Palm oil", Item)) %>% group_by(Year) %>% arrange(desc(Value), .by_group = TRUE) %>% slice(1:10)
big <- rbind(big, oil %>% na.omit() %>% filter(grepl("Cotton", Item)) %>% group_by(Year) %>% arrange(desc(Value), .by_group = TRUE) %>% slice(1:10))
big <- rbind(big, oil %>% na.omit() %>% filter(grepl("Sunflower", Item)) %>% group_by(Year) %>% arrange(desc(Value), .by_group = TRUE) %>% slice(1:10))
big <- rbind(big, oil %>% na.omit() %>% filter(grepl("Olive", Item)) %>% group_by(Year) %>% arrange(desc(Value), .by_group = TRUE) %>% slice(1:10))
big <- rbind(big, oil %>% na.omit() %>% filter(grepl("Soy", Item)) %>% group_by(Year) %>% arrange(desc(Value), .by_group = TRUE) %>% slice(1:10))
big <- rbind(big, oil %>% na.omit() %>% filter(grepl("Rapeseed", Item)) %>% group_by(Year) %>% arrange(desc(Value), .by_group = TRUE) %>% slice(1:10))

#Make a new tibble with the amount of times each country was in the top 10 for each different type of oil
cou <- big %>% group_by(Item) %>% count(Area)

#Make individual horizontal bar plots for each oil showing countries and the amount of times they were in the top 10 in production
#cou %>% filter(grepl("Palm", Item)) %>%  mutate(Area = fct_reorder(Area, n)) %>% ggplot(aes(Area,n)) + geom_col() + coord_flip() + labs(title = "Number of Years Each Country Has Been Top 10 in the\nWorld in Palm Oil Production", y = "Number of Years in Top 10", x = "Country") + theme(plot.title = element_text(hjust = .5))
#cou %>% filter(grepl("Cotton", Item)) %>%  mutate(Area = fct_reorder(Area, n)) %>% ggplot(aes(Area,n)) + geom_col() + coord_flip() + labs(title = "Number of Years Each Country Has Been Top 10 in the\nWorld in Cottonseed Oil Production", y = "Number of Years in Top 10", x = "Country") + theme(plot.title = element_text(hjust = .5))
#cou %>% filter(grepl("Sun", Item)) %>%  mutate(Area = fct_reorder(Area, n)) %>% ggplot(aes(Area,n)) + geom_col() + coord_flip() + labs(title = "Number of Years Each Country Has Been Top 10 in the\nWorld in Sunflower-seed Oil Production", y = "Number of Years in Top 10", x = "Country") + theme(plot.title = element_text(hjust = .5))
#cou %>% filter(grepl("Soy", Item)) %>%  mutate(Area = fct_reorder(Area, n)) %>% ggplot(aes(Area,n)) + geom_col() + coord_flip() + labs(title = "Number of Years Each Country Has Been Top 10 in the\nWorld in Soybean Oil Production", y = "Number of Years in Top 10", x = "Country") + theme(plot.title = element_text(hjust = .5))
#cou %>% filter(grepl("Rapeseed", Item)) %>%  mutate(Area = fct_reorder(Area, n)) %>% ggplot(aes(Area,n)) + geom_col() + coord_flip() + labs(title = "Number of Years Each Country Has Been Top 10 in the\nWorld in Canola Oil Production", y = "Number of Years in Top 10", x = "Country") + theme(plot.title = element_text(hjust = .5))
#cou %>% filter(grepl("Olive", Item)) %>%  mutate(Area = fct_reorder(Area, n)) %>% ggplot(aes(Area,n)) + geom_col() + coord_flip() + labs(title = "Number of Years Each Country Has Been Top 10 in the\nWorld in Olive Oil Production", y = "Number of Years in Top 10", x = "Country") + theme(plot.title = element_text(hjust = .5))

#Make a tibble of counts for each country to be used in the graph
c <- cou %>% group_by(Area) %>% summarise(sum(n))
c <- c %>% arrange(`sum(n)`)

#Complex and strung out stacked bar graph command
#Figure 2
cou %>% ggplot(aes(x = factor(Area, levels = c$Area), y = n, fill = Item, label = n)) + 
  geom_col() + 
  coord_flip() + 
  geom_text(size = 2, position = position_stack(vjust = .5)) + 
  labs(title = "Number of Years Each Country Has Been\nTop 10 in Oil Production Based on Each Oil Type", y = "Number of Years in Top 10", x = "Country") + 
  scale_fill_discrete(name = "Oil Type", labels = c("Cottonseed", "Olive", "Palm", "Canola", "Soy Bean", "Sunflower-seed")) + 
  theme(legend.position = "right", legend.key.size = unit(.2,'cm'), legend.key.width = unit(.25,'cm'), legend.title = element_text(size = 9), plot.title = element_text(hjust = .5))

#Take percentage of all plant oils of total plant porduction for every year
oilTotal <- oil %>% na.omit() %>% group_by(Year, Item) %>% summarise(sum(Value))
Percent <- oilTotal %>% group_by(Year) %>% summarise(Percent = (`sum(Value)` / sum(`sum(Value)`)), Item = unique(Item))

#Make line graph of the percentage table
#Figure 5a
Percent %>% filter(!Item == 'Palm kernels') %>% 
  ggplot() +
  geom_line(aes(x = Year, y = Percent, color = Item)) +
  labs(title = "Percentage of Total World Plant Oil Production" , color = "Oil Type") +
  scale_color_manual(labels = c("Coconut","Cottonseed","Olive","Palm","Canola","Soy Bean","Sunflower-seed"), values = c('gray', 'blue', 'brown', 'red', 'pink', 'orange', 'green')) +
  scale_fill_discrete(name = "Oil Type") + theme(legend.position = "right", legend.key.size = unit(.4,'cm'), legend.key.width = unit(.25,'cm'), legend.title = element_text(size = 9), plot.title = element_text(size = 11, hjust = .5))

#Make dot plot for palm oil only for percentage of total plant oil production
#Figure 5b
Percent %>% filter(!Item == 'Palm kernels') %>% filter(grepl("Palm oil", Item)) %>% 
  ggplot() +
  geom_point(aes(x = Year, y = Percent, color = Item)) +
  labs(title = "Percentage of Total World Plant Oil Production", color = "Oil Type") +
  scale_color_manual(labels = "Palm", values = 'red') +
  coord_cartesian(ylim = c(0,.4)) +
  scale_fill_discrete(name = "Oil Type") + theme(legend.position = "right", legend.key.size = unit(.2,'cm'), legend.key.width = unit(.25,'cm'), legend.title = element_text(size = 9), plot.title = element_text(size = 11, hjust = .5))

#Figure 4
top <- function(year) {
  topoil <- oil %>% filter(Year==year)
  topoil <- topoil %>% group_by(Area) %>% top_n(1,Value)
  colnames(topoil) <- c('Area','SOV_A3','Item','Year','Value')
  topmap <- left_join(map,topoil, by = 'SOV_A3')
  ggplot() +
    geom_sf(data=topmap, aes(geometry=geometry, fill=Item)) +
    ggtitle(paste(year, ": Top Oil Produced ", sep = ""))
}
top(2019)
top(1970)

#Figure 3
palmoil <- read_csv('Palmoil.csv')

palmoil <- palmoil %>% filter(Value!='NA')
palmoil <- palmoil %>% select(c(Area,Value, Year))
palmoil <- palmoil[1:2480,]

palmoil19 <- palmoil %>% filter(Year=='2019')
code <- read_xlsx('Copy of Country Code.xlsx')
colnames(code) <- c('Area','code','iso code')
palmoil19 <- right_join(code, palmoil19, by='Area')
palmoil19$`iso code`[48] <- 'CIV'
palmoil19 <- palmoil19 %>% filter(Area!= 'China, mainland')

map <- read_sf('Countries/ne_110m_admin_0_countries.shp')
colnames(palmoil19) <- c('Area','code','SOV_A3','Value','Year')
map19 <- left_join(map,palmoil19, by = 'SOV_A3')
my_breaks <- c(500, 3000,10000,1200000,25000000)

ggplot() +
  geom_sf(data=map19, aes(geometry=geometry, fill=(Value))) +
  ggtitle('2019 Palm Oil Production by Country') +
  scale_fill_gradient(name='Palm oil (tonnes)', trans='log', breaks=my_breaks)

palmoil80 <- palmoil %>% filter(Year=='1980')
code <- read_xlsx('Copy of Country Code.xlsx')
colnames(code) <- c('Area','code','iso code')
palmoil80 <- right_join(code, palmoil80, by='Area')
palmoil80$`iso code`[41] <- 'CIV'
palmoil80 <- palmoil80 %>% filter(Area!= 'China, mainland')

colnames(palmoil80) <- c('Area','code','SOV_A3','Value','Year')
map80 <- left_join(map,palmoil80, by = 'SOV_A3')
my_breaks <- c(500, 3000,10000,1200000,25000000)

ggplot() +
  geom_sf(data=map80, aes(geometry=geometry, fill=(Value))) +
  ggtitle('1980 Palm Oil Production by Country') +
  scale_fill_gradient(name='Palm oil (tonnes)', trans='log', breaks=my_breaks)
